# Deployment and release procedure

## Option A · stand-alone, file-open distribution

Extract the package. Open `index.html` or `dist/standalone/index.html`. No server, build or account. Core guides, projects, compiler and import/export are self-contained. The browser may expose IndexedDB, localStorage or only volatile memory under file URLs; check the persistence badge. SHA-256 may be unavailable in nonsecure browser contexts. **Use exported JSON backups.** A service worker cannot operate in this mode.

## Option B · modular web/PWA distribution

Copy the entire **contents of `dist/web/`** to a dedicated HTTPS site/subdirectory. Keep `index.html`, `css/`, `js/`, `data/`, `assets/`, `sw.js`, and `manifest.webmanifest` together. Configure the server for correct JS, CSS, JSON and webmanifest MIME types; do not enable directory indexing on private data. There are no secrets or private project records in the shipped website; project data lives in each user's browser.

Local development from the package root:

```bash
cd dist/web
python3 -m http.server 8000 --bind 127.0.0.1
# Visit http://127.0.0.1:8000/
```

A public hostname requires HTTPS, an appropriate scope and an actual browser. Service worker installed/ready and offline reloads must be tested in a normal browser. Installability varies by browser and policy. After changes to source: `python3 scripts/build.py`, redeploy all web files together, and test old and fresh browser profiles plus offline refresh. Build regenerates a content-based version for the static worker; old caches under the Foundry's prefix are removed on activation.

**Generated child ZIPs:** Extract first. Open `index.html` for local functionality; to use optional PWA files, serve that extracted directory over HTTPS or localhost. Do not upload `data/blueprint.json` without project stakeholders' authorization: it contains actual project location, intended outcomes, constraints and evidence references. The `data/module_pack.json` omits source project details but may include sensitive custom method descriptions; review it as well.

## Release checklist

- Verify trusted source, source rights, project scope and consent for included data; remove secrets and identifying details before hosting.
- Run `python3 scripts/run_tests.py` and address failures. Test normal HTTP/SW in your local environment; this production sandbox blocks navigation to local servers, so SW registration was **not verified here**.
- Test at 320px, 200% zoom, keyboard only, reduced motion and at least one screen reader with a qualified tester.
- Verify offline reload, storage fallbacks, form persistence, JSON round trips, corruption/malformed imports, calculated SHA-256 where available and file inventory integrity.
- Revalidate evidence, relevant domain experts, permissions, safety, accessibility, privacy and a rollback plan; built-in self-assessment alone is not certification.
- Deploy versioned assets atomically. Maintain a public changelog, record software provenance and preserve previous release archives.
