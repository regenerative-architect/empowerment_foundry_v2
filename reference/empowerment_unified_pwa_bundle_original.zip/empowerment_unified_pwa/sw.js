/* Foster + Navi Unified Foundry · bounded first-party application-shell cache.
   No analytics, no background synchronization, no caching third-party requests.
   Changes to APP_VERSION trigger a new install. Activation is user-controlled when
   an existing worker is present. Files opened directly by file:// never use SW. */
'use strict';
const APP_VERSION='2026-09-20-unified-v1';
const CACHE='fn_empowerment_unified_'+APP_VERSION;
const CORE=['./index.html','./manifest.webmanifest','./icon.svg','./icon-192.png','./icon-512.png'];
const SCOPE=new URL(self.registration.scope);
self.addEventListener('install', event=>event.waitUntil((async()=>{
  const cache=await caches.open(CACHE);
  await cache.addAll(CORE.map(p=>new URL(p,SCOPE).href));
})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{
  const keys=await caches.keys();
  await Promise.all(keys.filter(k=>k.startsWith('fn_empowerment_unified_')&&k!==CACHE).map(k=>caches.delete(k)));
  await self.clients.claim();
})()));
self.addEventListener('message',event=>{
  if(event.data && event.data.type==='SKIP_WAITING')self.skipWaiting();
});
self.addEventListener('fetch',event=>{
  const request=event.request;
  if(request.method!=='GET'||request.mode==='no-cors')return;
  const url=new URL(request.url);
  if(url.origin!==SCOPE.origin||!url.pathname.startsWith(SCOPE.pathname))return;
  if(request.mode==='navigate'){
    event.respondWith((async()=>{
      try{const result=await fetch(request);return result;}
      catch{const cached=await caches.match(new URL('./index.html',SCOPE).href);return cached||Response.error();}
    })());return;
  }
  if(!CORE.some(p=>new URL(p,SCOPE).href===url.href))return;
  event.respondWith((async()=>{
    const cached=await caches.match(request);if(cached)return cached;
    const response=await fetch(request);
    if(response.ok){const cache=await caches.open(CACHE);await cache.put(request,response.clone());}
    return response;
  })());
});
