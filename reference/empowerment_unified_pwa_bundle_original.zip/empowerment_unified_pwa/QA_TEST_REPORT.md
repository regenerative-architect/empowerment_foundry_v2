# QA test report · local build

## Tests performed

- Node.js syntax checks passed for the standalone main script, PWA main script, PWA bootstrap script and service worker.
- Parsed HTML has no duplicate `id` attributes; PWA manifest, three icon assets and five named precache resources are present.
- Exact byte comparison confirmed both supplied source HTML files were preserved in `sources/`.
- Chromium (`page.set_content` browser harness): no JavaScript exceptions in the tested workflows; 17 navigation routes; built-in merged checks **10/10 passed**.
- Ten detailed engine cards and 22 source cards rendered; recursive studio generated a 7,264-character brief and six prompt steps; energy arithmetic generated a numerical result and sensitivity bounds.
- Foundry project creation, Protocol fieldwork attachment, task completion and observation logging worked in the harness.
- Child app generated, previewed and accepted a new task (count increased from 8 to 9); preview sandbox now explicitly allows forms but continues to isolate origin.
- Legacy Protocol JSON migration preview + merge retained the sample project's seven tasks (including one checked), source note, one numeric observation and measurement method. Unified private backup included the fieldwork collection. A second empty session previewed and merged the exported unified backup and displayed all seven task controls with no JavaScript exceptions.
- 375px mobile viewport: drawer opened, closed on Escape, integrated engine appeared in global search and navigated to its route; no horizontal document overflow observed.

## Not established / release blockers

- Browser navigation to both `file://` and local HTTP was blocked by this test environment's administrator policy. The browser used `page.set_content`, which runs in a memory-only storage context. Consequently, browser reload persistence, direct file opening, downloaded-child independent-origin persistence and the actual service-worker install/offline lifecycle were **not** end-to-end tested.
- Manual screen-reader assessment, WCAG 2.2 AA conformance, pen testing, full cross-browser/device and field verification have not been performed.
- Publisher URLs and the original September 20, 2026 evidence summaries are source-preserved, **not independently reverified** during this integration.
- WebLLM/model weights, live research, hosted multiplayer, externally trusted timestamps and server-side federation are **not provided**. The core is deterministic and locally operable.
- The inherited Foundry's complete feature set was preserved structurally, but no exhaustive automated browser test of every original control has been run.

## Safety and provenance

Generated QA checks and badges are self-report/process aids, not certification of accessibility, real-world safety, authorship, legal priority or beneficial impact. SHA-256 manifests support later byte comparison only.
