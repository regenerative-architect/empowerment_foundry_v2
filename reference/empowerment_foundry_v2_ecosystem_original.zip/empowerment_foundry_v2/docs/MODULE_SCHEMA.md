# Module exchange contract (version 1)

File format: `empowerment_module_pack/1`; top-level `schema: 1`, `modules` and `methods` arrays. User-created, importable declarations must include all fields in this example. The Foundry also exports selected built-in modules in the same format, so other Foundry installations can resolve their IDs.

```json
{
  "format": "empowerment_module_pack/1",
  "schema": 1,
  "modules": [
    {
      "id": "module_test_training",
      "title": "Reviewed learning pathway",
      "version": "1.0.0",
      "domain": "education",
      "description": "A portable local learning design.",
      "method_ids": ["education_01"],
      "dependencies": ["module_education"],
      "requirements": ["Confirm learner consent"],
      "roles": ["Learners", "Qualified teachers"],
      "outputs": ["Accessible task plan"],
      "review": "Draft only; validate locally.",
      "provenance": "User-authored example, not independently verified."
    }
  ],
  "methods": []
}
```

Rules: module IDs lowercase with underscores, 3–71 characters; version is `major.minor.patch`; domain must match one of the 15 curated domains; dependencies must resolve to a built-in or imported module; method IDs must resolve to existing or accompanying valid method definitions. No cycles, duplicate IDs, prototype keys, code fields or script entrypoints. Maximum 512 KB import, 50 module declarations, 100 method records and bounded field lengths. Existing module/method IDs are never overwritten. The application neither signs imported packages nor verifies external claims of expertise or effectiveness.

A method definition includes `id`, `domain`, `title`, `overview`, `action`, `metric`, `risk`, and an array of `readiness` strings. Follow `src/data.json` for the reference shape. If you need multiple independent human perspectives, exchange packs as separate reviewed files; no servers, accounts or background network sync are provided.

See `examples/module_pack_example.json` for a standalone package with one new educational module and one original method. Inspect it before import, exactly as you would a file from someone else.
