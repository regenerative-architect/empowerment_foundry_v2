#!/usr/bin/env python3
from playwright.sync_api import sync_playwright
from pathlib import Path
import json,zipfile,tempfile,io,os
ROOT=Path(__file__).resolve().parents[1]
files=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 ctx=browser.new_context(accept_downloads=True,viewport={'width':1320,'height':900})
 p=ctx.new_page();errors=[];remote=[]
 p.on('pageerror',lambda e:errors.append(str(e)))
 p.on('request',lambda r:remote.append(r.url) if r.url.startswith(('http://','https://')) else None)
 p.set_content((ROOT/'dist/standalone/index.html').read_text(),wait_until='domcontentloaded')
 p.wait_for_function("!!window.FoundryEcosystem && document.getElementById('eco-status').textContent.includes('built-in')",timeout=15000)
 print('standalone status',p.locator('#eco-status').inner_text(),'routes',p.locator('#side-nav .navbtn').count())
 assert p.locator('#side-nav .navbtn').count()==13
 p.locator('[data-route="projects"]').first.click()
 p.locator('#project-title').fill('Seed Hub & <script>alert(1)</script>')
 p.locator('#project-domain').select_option('food');p.locator('#project-place').fill('Sample area for controlled trial')
 p.locator('#project-need').fill('Provisional observed needs; not a validated study')
 p.locator('#project-goal').fill('Document accessible seed distribution per season')
 p.locator('#project-save').click()
 p.locator('[data-route="ecosystem"]').first.click()
 assert p.locator('#eco-project').input_value()
 p.locator('#eco-domain').select_option('food')
 print('food registry visible',p.locator('#eco-modules .listcard').count())
 p.locator('#eco-select-domain').click()
 print('selected',p.locator('#eco-selection').inner_text())
 assert 'modules selected' in p.locator('#eco-selection').inner_text()
 p.locator('#eco-audit-run').click()
 assert 'review' in p.locator('#eco-audit').inner_text().lower()
 p.locator('#eco-consent').check()
 p.locator('#eco-audit-run').click()
 report=p.evaluate('window.FoundryEcosystem.audit()')
 print('audit',report['ok'],'method_count',report['method_count'],'notices',len(report['warnings']))
 assert report['ok'] and report['method_count']>=5
 with p.expect_download() as info:p.locator('#eco-pack').click()
 pack=info.value; packpath=Path(tempfile.gettempdir())/'foundry_modulepack_v2.json';pack.save_as(packpath)
 pk=json.loads(packpath.read_text());assert pk['format']=='empowerment_module_pack/1' and len(pk['modules'])>=1
 with p.expect_download() as info:p.locator('#eco-export-html').click()
 htmlpath=Path(tempfile.gettempdir())/'foundry_generated_child_v2.html';info.value.save_as(htmlpath)
 assert 'Seed Hub &amp; &lt;script&gt;' in htmlpath.read_text()
 # release a self-contained multi-file app + PWA resources
 p.locator('#eco-hosting').check()
 with p.expect_download(timeout=30000) as info:p.locator('#eco-export-zip').click()
 outpath=ROOT/'tests'/'generated_child_test.zip';info.value.save_as(outpath)
 with zipfile.ZipFile(outpath) as z:
  bad=z.testzip(); assert bad is None,bad
  names=set(z.namelist());print('generated ZIP files',len(names),'size',outpath.stat().st_size)
  assert {'index.html','assets/app.js','assets/app.css','data/blueprint.json','data/module_pack.json','data/assembly_audit.json','manifest.webmanifest','sw.js','SHA256SUMS.json','README.md'}<=names
  child=z.read('index.html').decode();assert '<script src="./assets/app.js"></script>' in child and '<link rel="stylesheet"' in child
  assert '<script>alert(1)</script>' not in child
  assert 'Seed Hub' in json.loads(z.read('data/blueprint.json'))['project']['title']
  hashes=json.loads(z.read('SHA256SUMS.json'));print('ZIP hashes',hashes['algorithm'],'count',len(hashes['files']))
  assert hashes['algorithm'] in ('SHA-256',None)
  for path,digest in hashes['files'].items():
   import hashlib
   assert hashlib.sha256(z.read(path)).hexdigest()==digest,path
  childdir=ROOT/'tests'/'child_temp';childdir.mkdir(exist_ok=True);z.extractall(childdir)
 # invalid imported pack rejected before mutation
 invalid={'format':'empowerment_module_pack/1','schema':1,'modules':[{'id':'bad','script':'alert(1)'}],'methods':[]}
 badfile=ROOT/'tests'/'invalid_module_pack.json';badfile.write_text(json.dumps(invalid))
 p.locator('#eco-import-file').set_input_files(str(badfile));p.locator('#eco-preview').click()
 p.wait_for_function("document.getElementById('eco-import-report').textContent.startsWith('REJECTED')",timeout=5000)
 assert 'REJECTED' in p.locator('#eco-import-report').inner_text()
 assert p.locator('#eco-import').is_disabled()
 print('browser exceptions',errors,'thirdparty requests',remote)
 assert not errors and not remote
 # Verify exported modular child with real HTTP via route interception (same content, external JS/CSS)
 childp=ctx.new_page();childp.on('pageerror',lambda e:errors.append('child:'+str(e)))
 # served from file:// may deny JS local resource? use server separately in runner.
 childp.set_content(htmlpath.read_text(),wait_until='domcontentloaded');childp.wait_for_timeout(200)
 assert childp.locator('.task').count()>=7
 print('standalone child tasks',childp.locator('.task').count())
 ctx.close();browser.close()
 print('PASS: standalone compiled UI, project, registry, selection, audit, consent, JSON, HTML, ZIP, hashes, injection and import rejection')
