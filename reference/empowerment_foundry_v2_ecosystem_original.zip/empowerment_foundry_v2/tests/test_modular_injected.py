#!/usr/bin/env python3
"""Browser injection fallback where local HTTP/browser navigation is administrator-blocked.
Does not claim to test service worker registration or true hosted offline operation.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import re,json,zipfile,hashlib
root=Path(__file__).resolve().parents[1];web=root/'dist/web'
src=(web/'index.html').read_text()
assert '<script src="./js/core.js"></script>' in src
assert '<link rel="manifest"' in src
src=src.replace('<link rel="stylesheet" href="./css/main.css">','<style>'+(web/'css/main.css').read_text()+'</style>')
src=re.sub(r'<script src="\./([^"<>]+)"></script>',lambda m:'<script>'+(web/m.group(1)).read_text()+'</script>',src)
sw=(web/'sw.js').read_text()
precache=json.loads(re.search(r'const ASSETS=(\[.*?\]);',sw).group(1))
for name in precache:
 if name!='./':assert (web/name[2:]).is_file(),name
manifest=json.loads((web/'manifest.webmanifest').read_text())
for icon in manifest['icons']:assert (web/icon['src'][2:]).exists()
release=json.loads((web/'SHA256SUMS.json').read_text())
for path,expected in release['hashes'].items():assert hashlib.sha256((web/path).read_bytes()).hexdigest()==expected,path
print('web inventory',len(precache),'precache paths and',len(release['hashes']),'artifact digests confirmed; service-worker registration untested')
with zipfile.ZipFile(root/'tests/generated_child_test.zip') as z:
 child=z.read('index.html').decode();child=child.replace('<link rel="stylesheet" href="./assets/app.css">','<style>'+z.read('assets/app.css').decode()+'</style>')
 child=child.replace('<script src="./assets/app.js"></script>','<script>'+z.read('assets/app.js').decode()+'</script>')
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 context=browser.new_context(viewport={'width':390,'height':844});page=context.new_page();errors=[]
 page.on('pageerror',lambda e:errors.append('web:'+str(e)))
 page.set_content(src,wait_until='domcontentloaded')
 page.wait_for_function("document.getElementById('eco-status').textContent.includes('built-in')")
 assert page.locator('#method-list .listcard').count()==60
 assert page.locator('#side-nav .navbtn').count()==13
 assert page.locator('#eco-modules .listcard').count()==20
 page.locator('#mobile-open').click();assert 'open' in page.locator('#sidebar').get_attribute('class')
 page.keyboard.press('Escape');assert 'open' not in page.locator('#sidebar').get_attribute('class')
 print('modular assets injected and running at narrow viewport; modules',page.locator('#eco-modules .listcard').count())
 cp=context.new_page();cp.on('pageerror',lambda e:errors.append('child:'+str(e)))
 cp.set_content(child,wait_until='domcontentloaded')
 cp.wait_for_timeout(100)
 count=cp.locator('.task').count();assert count>=7
 cp.locator('#new-task').fill('Check keyboard accessibility');cp.locator('#new-form button').click()
 assert cp.locator('.task').count()==count+1
 print('child split JS/CSS injected; task add works',count+1)
 assert not errors,errors
 context.close();browser.close()
print('PASS: modular asset wiring, static offline precache paths, release hashes, responsive navigation, generated split child interactions; NOT an HTTP/SW test')
