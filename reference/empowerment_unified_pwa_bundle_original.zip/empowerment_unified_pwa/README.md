# Foster + Navi · Unified Empowerment Foundry × Protocol

## What is actually included

- `standalone.html`: **complete single-file application**, containing the original Foundry's 60 methods / 63 *catalog references*, plus Protocol's 10 full research engines, 22 curated source records, four numeric model formulas, deterministic research prompt chains, integrated seven-stage fieldwork, observations, and an explicit migration of legacy Protocol JSON. No CDN or accounts.
- `index.html`: same fully embedded app plus a hosted-only manifest and service-worker registration. It still works if service-worker installation fails.
- `sw.js`, manifest, icon files: true optional installable PWA shell on HTTPS or localhost. Only named app-shell files are precached; third-party sites and personal files are not cached.
- `sources/`: both untouched source HTML originals as provided. Preserve these before importing existing browser records.
- Not included: WebLLM runtime, model weights, live AI inference, automatic internet research, live multiplayer, third-party authentication, or cryptographic timestamps. An entire model is not realistically embedded as a tiny single-file artifact; no WebLLM claims are made here.

## Standalone usage

Open `standalone.html` with a modern browser. You may rename it `index.html` for sharing. The file itself and built-in research/model/record workflows are offline; original publisher links require internet. Browser storage can differ across `file://` locations or browsers. Back up using **Backup** before relocating files or clearing browser data. Web Crypto digests may be unavailable in insecure contexts: app reports this instead of claiming hashing succeeded.

## Hosted PWA usage

Upload `index.html`, `sw.js`, `manifest.webmanifest`, `icon.svg`, and both PNG icons together to the same HTTPS directory, or run a local HTTP server at `http://localhost` for testing. Visit the page while online once. After successful service-worker installation/cache completion, the app shell can be navigated offline on the *same browser origin*. A first-visit offline request cannot work. Scope and installability depend on browser and deployment. Service-worker updates use a user-controlled activation button when an existing worker is present. A deployment to a new origin does **not** automatically migrate browser storage. Export JSON from the old app, then import on the new origin.

For local testing from inside this folder:

```sh
python3 -m http.server 8765
# visit http://localhost:8765/index.html
```

## Migrating the two originals

1. Export a **full private backup** from the old `empowerment_protocol_original.html` application in its original browser context.
2. Open the unified app, visit **Legacy import & checks**, choose the old Protocol JSON, preview the transformation, then explicitly merge. ID conflicts are skipped; the import never runs scripts and does not delete the original JSON.
3. For an old `empowerment_foundry_original.html` backup, use **Knowledge exchange** > Preview and validate > Merge. Optional fieldwork is backward compatible with the older Foundry backup envelope.
4. Export the new **complete PRIVATE JSON** and keep copies outside browser storage. Public/share exports intentionally omit private fieldwork notes. Always inspect the share candidate.

Legacy Protocol files never recorded a project location. Migrations label this as unknown. Original engine IDs, metric direction and task/observation data are retained. Domain mappings are grouped: skills → careers; resilience → water; navigator → civic; evidence → science; ecology → restoration; exchange → governance; foundry → digital. Repair gains an explicit dedicated domain. Do not mistake the mapped category for the original engine label.

## Verification and limitations

Use **Legacy import & checks** > Run merged-layer self-tests for pure-function checks; **Integrity & QA** also has self-reported manual release prompts. Testing must still cover physical browsers, Android/iOS, keyboard/screen reader, normal HTTPS/file storage, PWA refresh, offline service-worker lifecycle, export/import round trips and external source validity before broad release. No claims of external certification, independently proven impact or verified timestamps.

The child compiler intentionally emits a *bounded local task board*, not arbitrary applications. Its preview sandbox permits forms/scripts/downloads but not `allow-same-origin`; browser preview storage may fail. A downloaded child runs on its own browser origin and has independent storage.

## Data, ethics, source attribution and licensing

No analytics, hidden telemetry, uploads, auto-email or remote scripts. All import text is bounded, validated and rendered as escaped text. Legacy migrations preserve failures and observations; stop conditions require human judgment. Source bibliography is a dated snapshot provided in the original Protocol (2026-09-20), not independently reverified in this build. A's authorship/reuse statement does not select an explicit license; B's supplied footer states MIT. Original files are preserved, and license permissions for the merged distribution should be confirmed by the relevant rights holder before republishing under a new license. Third-party linked sources retain their individual terms.

**Zero-harm / anti-inversion:** do not turn documentation, self-reported gates, XP, hashes or simulated metrics into credentials, surveillance, real-world certification or claims of causal benefit. Obtain permission, protect personal/Indigenous/community data rights, test reversible interventions and report adverse or null outcomes.
