#!/usr/bin/env python3
"""Run the portable structural/browser suite. Hosted SW integration is optional."""
from pathlib import Path
import subprocess,sys,shutil,zipfile,json,hashlib
root=Path(__file__).resolve().parents[1]
print('Running Foundry v2 release suite',flush=True)
subprocess.run([sys.executable,str(root/'scripts/build.py')],cwd=root,check=True)
node=shutil.which('node')
if node:
 for p in [root/'src/app.js',root/'src/ecosystem.js',root/'dist/web/sw.js']:
  subprocess.run([node,'--check',str(p)],check=True)
 print('PASS: JavaScript syntax checks',flush=True)
else:print('SKIP: Node not installed; browser tests still parse and execute JS',flush=True)
for file in ['test_ecosystem_browser.py','test_module_exchange.py','test_modular_injected.py']:
 print('Running:',file,flush=True)
 subprocess.run([sys.executable,str(root/'tests'/file)],cwd=root,check=True)
with zipfile.ZipFile(root/'tests/generated_child_test.zip') as z:assert z.testzip() is None
with zipfile.ZipFile(root/'reference/next_gen_html_atlas_v2_verified.zip') as z:assert z.testzip() is None
for rel in ['dist/standalone/index.html','dist/web/index.html','dist/web/sw.js','src/registry.json','examples/module_pack_example.json']:
 assert (root/rel).is_file(),rel
print('PASS: all runnable tests and both included ZIP inventories; service-worker HTTP installation remains a separate deployment test',flush=True)
