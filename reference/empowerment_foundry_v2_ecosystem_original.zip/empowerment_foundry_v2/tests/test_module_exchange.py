#!/usr/bin/env python3
from playwright.sync_api import sync_playwright
from pathlib import Path
import tempfile,json
root=Path(__file__).resolve().parents[1]
method={'id':'sample_training','domain':'education','title':'Community learning bridge','overview':'Test a supervised knowledge exchange.','action':'Create an accessible learning task plan.','metric':'Count independently verified participant feedback.','risk':'Avoid presumed credentials and unwanted private data.','readiness':['Obtain consent','Identify review authority']}
module={'id':'module_training_bridge','title':'Learning bridge test','version':'1.2.0','domain':'education','description':'Exchange a portable, human-reviewed learning module.','review':'Local review is required before deployment.','provenance':'Illustrative offline test, not an independent evidence source.','method_ids':['sample_training','education_01'],'dependencies':['module_education'],'requirements':['Verify consent'],'roles':['Learner','Reviewer'],'outputs':['Learning pathway','Test plan']}
pack={'format':'empowerment_module_pack/1','schema':1,'methods':[method],'modules':[module]}
with tempfile.TemporaryDirectory() as td:
 valid=Path(td)/'valid.json';valid.write_text(json.dumps(pack))
 cycle=Path(td)/'cycle.json';c=json.loads(json.dumps(pack));c['modules'][0]['dependencies']=['module_training_bridge'];cycle.write_text(json.dumps(c))
 with sync_playwright() as pw:
  browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  ctx=browser.new_context(accept_downloads=True);p=ctx.new_page();errors=[]
  p.on('pageerror',lambda e:errors.append(str(e)));p.on('dialog',lambda d:d.accept())
  p.set_content((root/'dist/standalone/index.html').read_text(),wait_until='domcontentloaded')
  p.wait_for_function("document.getElementById('eco-status').textContent.includes('built-in')")
  p.locator('[data-route="ecosystem"]').first.click()
  p.locator('#eco-import-file').set_input_files(str(cycle));p.locator('#eco-preview').click()
  p.wait_for_function("document.getElementById('eco-import-report').textContent.startsWith('REJECTED')")
  print('cyclic import rejected:',p.locator('#eco-import-report').inner_text()[:160])
  p.locator('#eco-import-file').set_input_files(str(valid));p.locator('#eco-preview').click()
  p.wait_for_function("document.getElementById('eco-import-report').textContent.startsWith('STRUCTURE VALIDATED')")
  assert not p.locator('#eco-import').is_disabled()
  p.locator('#eco-import').click();p.wait_for_function("document.getElementById('eco-status').textContent.includes('1 imported')")
  st=p.evaluate('window.FoundryBridge.snapshot()')
  assert len(st['customMethods'])==1 and len(st['ecosystem']['customModules'])==1
  print('new method and module recorded',st['customMethods'][0]['id'],st['ecosystem']['customModules'][0]['id'])
  # Re-import identical ID: checked but no duplicate and no overwrite.
  p.locator('#eco-import-file').set_input_files(str(valid));p.locator('#eco-preview').click()
  p.wait_for_function("document.getElementById('eco-import-report').textContent.startsWith('STRUCTURE VALIDATED')")
  p.locator('#eco-import').click()
  after=p.evaluate('window.FoundryBridge.snapshot()')
  assert len(after['customMethods'])==1 and len(after['ecosystem']['customModules'])==1
  # Full workspace exports new modules and remains valid for importer.
  p.locator('[data-route="exchange"]').first.click()
  with p.expect_download() as event:p.locator('#export-full').click()
  exported=Path(td)/'full.json';event.value.save_as(exported)
  bk=json.loads(exported.read_text())
  assert len(bk['ecosystem']['customModules'])==1 and len(bk['customMethods'])==1
  p.locator('#import-file').set_input_files(str(exported));p.locator('#import-preview-btn').click()
  p.wait_for_function("document.getElementById('import-report').textContent.includes('Full workspace')")
  print('full backup validates with ecosystem module records')
  assert not errors,errors
  ctx.close();browser.close()
 print('PASS: cycle rejection, reviewed JSON import, safe id collisions, private backup roundtrip validation')
