# Implemented vs not implemented

| Capability | Actual implementation | Boundary |
| --- | --- | --- |
| Project commons and generative prompts | Existing working forms, blueprint, domain methods, audience and mutation contracts | No AI execution or autonomous web retrieval |
| Empowerment library | 60 method records, 15 domains and readable field guides | Method efficacy not independently assessed |
| Technology atlas | Metadata of 41 labs and 22 integrations from attached reference | The original 63 applications are not automatically installed as modules |
| Module registry | 20 built-in, declarative manifests with typed reference sets | Imported manifests do not execute code or install apps |
| Custom pack exchange | Validated JSON, preview, explicit approval, ID-conflict preservation | Manual files, not live multiplayer networking |
| Module graph | Resolves dependency chains; blocks unknown and cyclical references | Does not prove cross-domain interventions are compatible |
| Application compilation | Actual standalone task app and modular ZIP, CSS/JS, JSON, documentation | Child app is a bounded task tool, not an arbitrary software generator |
| Review gates | Eight source safeguards, blocked status prevents child export, consent required | Unassessed gates produce warnings; audit is not certification |
| Privacy / portability | Full workspace JSON, module pack, original public share candidate | Generated blueprints may include private text, require review |
| Integrity | ZIP CRC-32, SHA-256 when Web Crypto exists; build manifest hashes | No cryptographic signatures or independently trusted timestamps |
| PWA | Hosted modular manifest, icons, service worker and versioned precache code | Live install/true offline reload untested in this restricted environment |
| Storage | IndexedDB → localStorage → memory fallback | Not encrypted; browser-profile persistence not end-to-end tested for all browsers |
| Security tests | Invalid module reject, cycle reject, HTML injection escape, ZIP extraction and static hashes | Not a third-party security penetration test |
| Accessibility | Semantic navigation, labels, responsive/mobile drawer, reduced-motion and focus styles | No screen-reader certification or complete WCAG audit |
| Research and outcomes | Evidence ledger, falsifiers, numeric descriptive comparisons | No external live facts, causal proof or measured impact |
