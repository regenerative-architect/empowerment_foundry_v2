#!/usr/bin/env python3
"""Deterministic declarative registry derived from the supplied Foundry dataset."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
data=json.loads((ROOT/'src/data.json').read_text())
recipes={
'food':('Food access and edible infrastructure','Households, food cooperatives, municipal operators','Local supply map; food safety review; accessibility plan; pilot ledger'),
'water':('Water resilience','Households, water stewards, qualified operators','Water balance; qualified safety review; monitoring plan; rollback trigger'),
'restoration':('Restoration and living infrastructure','Land stewards, Indigenous rights-holders, ecological operators','Site assessment; biodiversity baseline; maintenance map; adaptive monitoring'),
'housing':('Housing and mutual care','Residents, housing organizations, service providers','Consent-based needs analysis; service map; safety plan; evaluation design'),
'education':('Learner empowerment','Learners, teachers, education organizations','Learning objectives; accessible activities; consent; feedback and assessment'),
'careers':('Capability-to-career bridge','Learners, employers, training providers','Task taxonomy; transferable skills; credential checks; paid pathway hypothesis'),
'civic':('Civic information commons','Residents, institutions, affected rights-holders','Source ledger; procedural map; accessible neutral brief; feedback and corrections'),
'peace':('Conflict prevention and human security','Local mediators, service providers, rights-holders','Do-no-harm review; escalation pathways; rights protections; independent oversight'),
'health':('Care navigation and referral','Residents, clinicians, qualified service providers','Verified contact directory; referral boundaries; data minimization; accessibility'),
'privacy':('Consent and provenance workbench','Data stewards, individuals, organizations','Data map; consent log; provenance limitations; audit and deletion process'),
'governance':('Cooperative governance kit','Members, worker groups, board stewards','Decision rights; appeal mechanism; stewardship plan; independent exit'),
'science':('Evidence and reproducibility lab','Researchers, practitioners, community observers','Hypothesis; protocol; comparable data; falsifier; negative results'),
'digital':('Local-first digital public goods','Independent developers, community maintainers','Data schema; accessible prototype; offline test; export and migration'),
'media':('Knowledge transfer and storytelling','Educators, communicators, contributors','Source attributions; accessible narrative; publication consent; correction path'),
'children':('Child-and-family agency','Children, families, educators, safeguarding experts','Age-appropriate choice; adult-supported safety; inclusion; guardian privacy review'),
}
modules=[]
for d in data['domains']:
  mid='module_'+d['id']; title,roles,outputs=recipes[d['id']]
  ids=[m['id'] for m in data['methods'] if m['domain']==d['id']]
  modules.append(dict(id=mid,title=title,version='1.0.0',domain=d['id'],description=d['description'],method_ids=ids,requirements=['Baseline and credible alternative','Rights-holder consultation and consent','Qualified safety review where relevant','Outcome measurement and stop rule'],roles=roles.split(', '),outputs=outputs.split('; '),dependencies=[],review='Human review required; project descriptions do not establish impact or authorization.',provenance='Curated from Foster + Navi Empowerment Foundry methods; not independently certified.',built_in=True))
inter=[
('module_evidence_bridge','Evidence-to-design bridge',['privacy_01','science_01','digital_01'],'science','Turn claims into explicit test plans with reproducible, consented records.'),
('module_resilience_bridge','Household-to-community resilience',['food_01','water_01','housing_01','children_01'],'food','Combine resource access plans without presuming permissions or technical safety.'),
('module_learning_bridge','Education-to-work capability bridge',['education_01','careers_01','children_01'],'education','Trace learner-selected skills to verified training and paid opportunities.'),
('module_stewardship_bridge','Local governance and maintenance bridge',['governance_01','restoration_01','digital_01'],'governance','Design stewardship, maintenance, independent handover and an exit mechanism.'),
('module_knowledge_bridge','Portable public knowledge bridge',['media_01','science_01','privacy_01'],'media','Make methods explainable, reusable, reviewable and privacy-preserving.'),
]
ids={m['id'] for m in data['methods']}
for mid,title,mids,domain,description in inter:
 assert all(x in ids for x in mids)
 modules.append(dict(id=mid,title=title,version='1.0.0',domain=domain,description=description,method_ids=mids,requirements=['Cross-domain dependency check','Independent authority and safety signoff','Evidence and adverse-outcome plan'],roles=['Local stewards','Affected participants','Qualified reviewers'],outputs=['Interoperability map','Combined method contract','Bounded pilot specification'],dependencies=[],review='Composition is a design hypothesis, not evidence that the methods work together.',provenance='Foster + Navi generative ecosystem synthesis.',built_in=True))
assert len(modules)==20
out={'format':'empowerment_registry/1','registry_version':'2.0.0','policy':'Declarative, non-executable module manifests only. Imported packs require explicit review.','modules':modules}
(ROOT/'src/registry.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('Registry created:',len(modules),'modules; referenced method IDs:',len({id for m in modules for id in m['method_ids']}))
