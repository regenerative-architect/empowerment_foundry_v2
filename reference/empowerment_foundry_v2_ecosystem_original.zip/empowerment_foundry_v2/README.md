# Foster + Navi · Empowerment Foundry v2

**A local-first generative ecosystem: one source codebase, two distributions, and a browser-based child-application compiler.**

This package synthesizes the Empowerment Foundry and the user's Next-Generation HTML Atlas v2. It retains **15 domains, 60 actionable method definitions, 63 technology references, evidence/measurement and capability workbenches**, and adds a **20-module declarative registry, import validation, project composition, generated multi-file ZIPs, review gates and versioned PWA source**. It does not perform autonomous AI inference, online research, live multiplayer networking, actual field operations or certification.

## Open the right edition

**Fastest / offline single-file:** Open `index.html` at the ZIP's root after extracting it. The equivalent canonical build is `dist/standalone/index.html`; it embeds core content, registry, CSS and JS, and does not need a web server. Local storage support varies by browser. Export backups.

**Hosted / modular:** Deploy the **contents** of `dist/web/` together at one HTTPS URL, or from a local development server for testing. Open its `index.html`. The web edition separates CSS, JS, JSON and assets, and includes a manifest and scoped versioned service worker. Opening it as `file://` can display the app but will **not** register its service worker. After first successful hosted load and cache installation, revisit offline to verify for your browser.

**Build / contribute:** Inspect `src/`, `scripts/`, `docs/`, `tests/`. No Node build, CDN or third-party runtime library. Requires **Python 3 standard library** to rebuild. Browser tests are optional and require Playwright + Chromium. `reference/` preserves the unmodified supplied HTML Atlas ZIP separately; the Foundry uses its catalog *metadata*, not all 63 original web apps as installed functionality.

## Use the next-generation workflow

1. **Project commons:** Create a user-defined project. Record the real need, intended outcome and constraints; do not put confidential details into an artifact you intend to share.
2. **Module ecosystem:** Choose project; search and enable modules. Dependencies are resolved transitively and missing or cyclic references prevent compilation. Inspect module obligations and outputs.
3. **Review:** Examine the project's text, intended export and eight safeguard records. Affirm authorization to export those records. A blocked safeguard prevents compilation; unassessed gates remain clearly flagged.
4. **Compile:** Export either a fully standalone child `index.html` or a modular **ZIP with working task app**, CSS/JS, project blueprint, selected module/method JSON, audit record, README, MIT text and SHA-256 checksums when Web Crypto is available. Optional PWA files are included only when selected.
5. **Exchange:** Export and import `empowerment_module_pack/1` declarative JSON; preview, validate and explicitly approve. No imported JS runs; no existing IDs are overwritten. Full private backups also include the custom registry.
6. **Verify:** Extract the generated ZIP, open or locally serve the child app, exercise tasks, JSON backup/import, accessibility and secure-hosted offline behavior where applicable. Do not treat a generated design as real-world deployment or proof of impact.

## Package map

| Path | Purpose |
| --- | --- |
| `index.html` | Root quick-start, complete single-file Foundry |
| `dist/standalone/index.html` | Canonical complete single-file build |
| `dist/web/index.html` | Multi-file, hostable Foundry; keep its sibling directories |
| `dist/web/sw.js`, `manifest.webmanifest` | Scoped offline cache and installation metadata |
| `src/shell.html`, `app.js`, `ecosystem.js` | Maintained UI, existing tools and new module/ZIP engine |
| `src/data.json`, `registry.json`, `assets/` | Curated content, module contracts, locally generated icons |
| `scripts/make_registry.py`, `build.py`, `run_tests.py` | Registry, both compiled editions, browser/static checks |
| `docs/` | Architecture, schemas, release procedures, security, test report and preview |
| `reference/next_gen_html_atlas_v2_verified.zip` | Supplied reference material; not all features implemented in Foundry |

## Rebuild and test

From inside the extracted package:

```bash
python3 scripts/build.py
python3 scripts/run_tests.py
```

`make_registry.py` regenerates the curated built-in registry from `data.json` and its recipes; only run it deliberately after editing that design. The test runner assembles a sample child ZIP and tests validated imports before checking modular wiring. If your browser prohibits local HTTP navigation, the runner uses injected browser documents; that verifies UI and file wiring but **does not verify live service-worker installation**.

See `docs/ARCHITECTURE.md`, `docs/MODULE_SCHEMA.md`, `docs/DEPLOYMENT.md`, `docs/SECURITY.md`, `docs/TESTING.md` and `docs/FEATURE_MATRIX.md`.

**Attribution:** Foster + Navi, 2026. MIT for this software; see `LICENSE`. The supplied reference archive is preserved as received and retains its own license/attribution. User-entered project data and third-party methods may have different rights: check them before distributing. No analytics, accounts, remote model calls or hidden uploads.
