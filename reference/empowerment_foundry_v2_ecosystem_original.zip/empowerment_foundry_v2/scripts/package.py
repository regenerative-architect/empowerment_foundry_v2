#!/usr/bin/env python3
"""Build release archives from the verified source tree; no network/dependencies."""
from pathlib import Path
import zipfile,hashlib,json,shutil
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent
EXCLUDED={'release_manifest.json','generated_child_test.zip','invalid_module_pack.json'}
paths=[]
for p in sorted(ROOT.rglob('*')):
 if not p.is_file() or p.name in EXCLUDED or '__pycache__' in p.parts:continue
 rel=p.relative_to(ROOT).as_posix()
 if rel.startswith('tests/child_temp/'):continue
 paths.append((p,rel))
manifest={'format':'empowerment_foundry_release/2','scope':'Byte inventory, not independent timestamp/authorship or field approval','contents':{'domains':15,'methods':60,'technology':63,'modules':20},'files':{name:hashlib.sha256(p.read_bytes()).hexdigest() for p,name in paths}}
(ROOT/'release_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
paths.append((ROOT/'release_manifest.json','release_manifest.json'))
def archive(output,records,prefix=''):
 with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=True) as z:
  for p,name in records:
   info=zipfile.ZipInfo(prefix+name,date_time=(2026,9,20,0,0,0))
   info.compress_type=zipfile.ZIP_DEFLATED
   info.external_attr=0o644<<16
   z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
 with zipfile.ZipFile(output) as z:
  assert z.testzip() is None,'ZIP integrity failure'
  assert len(z.namelist())==len(set(z.namelist())),'Duplicate ZIP path'
 return output.stat().st_size,len(records)
complete=OUT/'empowerment_foundry_v2_ecosystem.zip'
size,n=archive(complete,paths,'empowerment_foundry_v2/')
web=OUT/'empowerment_foundry_v2_hosted.zip'
webfiles=[(p,p.relative_to(ROOT/'dist/web').as_posix()) for p,name in paths if name.startswith('dist/web/')]
ws,wn=archive(web,webfiles)
standalone=OUT/'empowerment_foundry_v2_index.html'
shutil.copy2(ROOT/'index.html',standalone)
assert standalone.read_bytes()==(ROOT/'dist/standalone/index.html').read_bytes()
# Reverify source inventory against contents extracted logically from the ZIP.
with zipfile.ZipFile(complete) as z:
 for name,digest in manifest['files'].items():
  assert hashlib.sha256(z.read('empowerment_foundry_v2/'+name)).hexdigest()==digest,name
 assert z.read('empowerment_foundry_v2/release_manifest.json')== (ROOT/'release_manifest.json').read_bytes()
with zipfile.ZipFile(web) as z:
 for p,name in webfiles:
  assert hashlib.sha256(z.read(name)).digest()==hashlib.sha256(p.read_bytes()).digest(),name
print('COMPLETE:',complete,'bytes:',size,'files:',n)
print('HOSTED:',web,'bytes:',ws,'files:',wn)
print('STANDALONE:',standalone,'bytes:',standalone.stat().st_size)
print('VERIFIED: ZIP CRC, unique file paths, SHA-256 per release file, identical standalone output')
