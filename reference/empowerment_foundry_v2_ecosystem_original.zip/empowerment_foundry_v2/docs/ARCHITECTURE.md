# Architecture · independent modules, compiled outputs

## One source, two product editions

`src/shell.html` is the HTML application shell with accessible sidebar + top navigation, semantic pages, offline-readable guides and embedded CSS. `src/app.js` supplies the existing 12 workbenches, local state, core project/evidence/method/impact stores, blueprint/child compiler and a strictly bounded bridge. `src/ecosystem.js` consumes the bridge to supply the thirteenth workbench. `src/data.json` is the curated domain/method/technology bank. `src/registry.json` declares 20 compatible module contracts. `scripts/build.py` assembles the same components into standalone HTML and an equivalent modular web edition. Python 3 standard library only; icons are committed assets.

Main data flow:

```
Curated methods / original Atlas metadata / module registry
                  ↓
          User project (local)
                  ↓
     Selected declarative modules
       ↳ dependency DAG check
       ↳ known method ID check
       ↳ rights and safeguard review
       ↳ explicit export consent
                  ↓
        Reproducible blueprint
                  ↓
  Existing child HTML compiler, with selected methods
        ↙                         ↘
 Single-file child HTML      Modular child ZIP
                              ├── runnable index.html
                              ├── assets/app.css + app.js + icon.svg
                              ├── data/blueprint.json
                              ├── data/module_pack.json
                              ├── data/assembly_audit.json
                              ├── README.md + LICENSE
                              ├── SHA256SUMS.json (if Web Crypto)
                              └── optional manifest + sw.js
```

The core compiler is **deterministic with respect to data selections except local creation times and generated task IDs**. These are local values, not cryptographic temporal attestations. Generated app functionality is deliberately bounded: an editable task board, local notes, JSON import/export, reset and remix-prompt generator. The program does **not** compile arbitrary module code or invent functionality to match every domain.

## Registry and trust boundary

A module is a JSON record: domain, title, version, method IDs, dependencies, requirements, stakeholders, outputs, safety review and provenance. Module dependency resolution uses depth-first traversal with cycle detection; missing dependencies and methods are blocked. Imported method definitions use the original Foundry validator, and new modules pass the core ecosystem schema plus extension-level dependency review. Conflicting built-in or existing IDs are preserved (never overwritten).

**Imports are data, not executable extensions.** No `eval`, dynamically loaded script, module URL, template execution, HTML insertion of raw untrusted text, or server-side processing. Importing a module never starts any external activity. Users explicitly approve import after preview. Persisted modules live in the same validated private workspace backup as the original records.

## State / persistence

Core store: IndexedDB when available → localStorage fallback → in-memory fallback, always reported in the interface. The workspace remains `empowerment_foundry/1` for compatibility with earlier backups, with optional `ecosystem` object. The import validator supplies defaults when reading older compatible backups. Full backups include custom modules and per-project module assignments. Public/share candidates from the original workbench intentionally omit private evidence; **generated child blueprints do not automatically redact project metadata** and require specific export authorization.

## ZIP algorithm

The in-browser writer implements ZIP local headers, STORE entries, central directory, end-of-central-directory and CRC-32; file names are controlled and reject traversal and duplicates; file and archive byte limits apply. When `crypto.subtle` exists, it also writes SHA-256 per-file digests in `SHA256SUMS.json`. If unavailable it writes a manifest with an explicit unavailable status, never fabricated values. CRC-32 is accidental-corruption detection, not a secure authenticity guarantee; SHA-256 is byte identity, not a verified historical timestamp or signature.

## Hosted offline caching

Only the modular edition contains a service worker. It registers only on HTTPS or localhost, caches an explicit versioned same-origin asset inventory and cleans older caches under its own prefix; it does not cache third-party responses or perform background sync. A file opened from a ZIP or `file://` cannot use normal service-worker installation. Network-free operation must be verified on the actual target browser after an initial hosted visit.

## Implementation boundaries

No live AI inference, automated online research, real multiuser collaboration, automatic deployments, cross-browser accessibility certification, domain safety approval, software supply-chain attestation or measured social impact. Actual government, organization and local authority policies must be independently checked. Versioned data exchange is a collaboration *protocol*, not a live peer network.
