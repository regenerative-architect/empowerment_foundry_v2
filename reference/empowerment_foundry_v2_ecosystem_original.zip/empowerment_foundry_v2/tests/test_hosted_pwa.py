#!/usr/bin/env python3
"""Hosted and generated-child checks in Chromium, including service-worker offline cache."""
from pathlib import Path
from playwright.sync_api import sync_playwright, Error as PlaywrightError
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from functools import partial
import threading, tempfile, shutil,zipfile,json,hashlib,os
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='foundry_http_') as tmp:
 base=Path(tmp);shutil.copytree(root/'dist/web',base/'web')
 childzip=root/'tests/generated_child_test.zip'
 assert childzip.exists(),'Run test_ecosystem_browser.py first.'
 with zipfile.ZipFile(childzip) as z:z.extractall(base/'child')
 handler=partial(SimpleHTTPRequestHandler,directory=str(base))
 server=ThreadingHTTPServer(('127.0.0.1',0),handler);port=server.server_address[1]
 thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
 try:
  with sync_playwright() as pw:
   browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
   ctx=browser.new_context(accept_downloads=True)
   p=ctx.new_page();errors=[];external=[]
   p.on('pageerror',lambda e:errors.append('web:'+str(e)))
   p.on('request',lambda r:external.append(r.url) if r.url.startswith(('https://','http://')) and f'127.0.0.1:{port}/' not in r.url else None)
   try:
    p.goto(f'http://127.0.0.1:{port}/web/index.html',wait_until='networkidle')
   except PlaywrightError as exc:
    if 'ERR_BLOCKED_BY_ADMINISTRATOR' in str(exc):
     print('SKIP: sandbox administrator blocks local HTTP navigation; SW installation not tested');ctx.close();browser.close();raise SystemExit(0)
    raise
   p.wait_for_function("document.getElementById('eco-status').textContent.includes('built-in')",timeout=10000)
   sw=p.evaluate("async () => {const s=await navigator.serviceWorker.ready;return {scope:s.scope,active:s.active.state,controlled:!!navigator.serviceWorker.controller}}")
   print('web',p.title(),'registry',p.locator('#eco-status').inner_text(),'SW',sw)
   assert '/web/' in sw['scope'] and sw['active']=='activated'
   assert p.locator('#side-nav .navbtn').count()==13
   assert p.locator('#method-list .listcard').count()==60
   # Worker takes page control after activation or reload.
   p.reload(wait_until='networkidle');p.wait_for_function('!!navigator.serviceWorker.controller',timeout=10000)
   ctx.set_offline(True);p.reload(wait_until='domcontentloaded')
   p.wait_for_function("document.getElementById('eco-status').textContent.includes('built-in')",timeout=10000)
   print('main hosted edition reload offline',p.locator('#eco-status').inner_text())
   ctx.set_offline(False)
   # Test child ZIP actual split assets, functional form, SHA and SW.
   c=ctx.new_page();c.on('pageerror',lambda e:errors.append('child:'+str(e)))
   c.goto(f'http://127.0.0.1:{port}/child/index.html',wait_until='networkidle')
   assert c.locator('.task').count()>=7
   c.locator('#new-task').fill('Check water and food sharing accessibility');c.locator('#new-form button').click()
   assert c.locator('.task').count()>=8
   c.reload(wait_until='domcontentloaded')
   assert c.locator('.task').count()>=8
   child_sw=c.evaluate("async () => {let s=await navigator.serviceWorker.ready;return s.scope}")
   assert '/child/' in child_sw
   print('child modular app tasks after reload',c.locator('.task').count(),'SW scope',child_sw)
   c.reload(wait_until='networkidle');ctx.set_offline(True);c.reload(wait_until='domcontentloaded')
   assert c.locator('.task').count()>=8
   ctx.set_offline(False)
   # Secure context SHA integrity exporter. New simple project in hosted web.
   p.locator('[data-route="projects"]').first.click()
   p.locator('#project-title').fill('Local civic reading room')
   p.locator('#project-domain').select_option('education')
   p.locator('#project-place').fill('Illustrative town')
   p.locator('#project-need').fill('Needs a private learning task board')
   p.locator('#project-goal').fill('Provide a reusable learning method library')
   p.locator('#project-save').click()
   p.locator('[data-route="ecosystem"]').first.click()
   p.locator('#eco-select-domain').click();p.locator('#eco-consent').check()
   with p.expect_download(timeout=30000) as event:p.locator('#eco-export-zip').click()
   path=base/'secured.zip';event.value.save_as(path)
   with zipfile.ZipFile(path) as z:
    assert z.testzip() is None
    hashes=json.loads(z.read('SHA256SUMS.json'))
    assert hashes['algorithm']=='SHA-256',hashes
    assert len(hashes['files'])>=8
    for name,digest in hashes['files'].items():assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
   print('hosted compiler checksums',len(hashes['files']),'verified SHA-256')
   assert not errors,errors
   assert not external,external
   ctx.close();browser.close()
  print('PASS: modular hosted UI, 60 methods, PWA registration, offline reload, modular generated child, persistence, child offline reload, SHA-256 digests')
 finally:server.shutdown();server.server_close()
