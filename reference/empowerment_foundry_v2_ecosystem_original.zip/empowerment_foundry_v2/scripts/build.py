#!/usr/bin/env python3
"""Reproducible static build: same source -> standalone HTML and modular hosted PWA.
No package manager, CDN, build-time remote requests or runtime dependency is required.
"""
from pathlib import Path
import json,re,hashlib,zipfile,shutil,datetime,io
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'src';DIST=ROOT/'dist'
shell=(SRC/'shell.html').read_text();app=(SRC/'app.js').read_text();extension=(SRC/'ecosystem.js').read_text()
data=json.loads((SRC/'data.json').read_text());registry=json.loads((SRC/'registry.json').read_text())
assert len(data['domains'])==15 and len(data['methods'])==60 and len(data['technology'])==63 and len(registry['modules'])==20
assert all(t in shell for t in ['__DATA__','__JS__','__GUIDES__'])
assert '</script' not in app.lower() and '</script' not in extension.lower()
def sanitize(s):return __import__('html').escape(str(s),quote=True)
def guides():
 out=[]
 for d in data['domains']:
  ms=[m for m in data['methods'] if m['domain']==d['id']]
  out.append(f'<details class="domain-guide" id="domain-{sanitize(d["id"])}"><summary>{sanitize(d["title"])} · {len(ms)} reusable methods</summary><div class="detail"><p><strong>Scope.</strong> {sanitize(d["description"])}. These are design methods, not professional, legal or clinical approvals.</p><p><strong>Workflow:</strong> (1) consult rights-holders; (2) establish baseline, timeframe and alternative; (3) select maintainable methods; (4) secure consent and expert reviews; (5) pilot reversibly; (6) measure positive, negative and null outcomes; (7) export reviewed, privacy-minimized knowledge.</p><p><strong>Safeguards:</strong> Distinguish observation and inference, lifecycle cost and burdens, competing explanations and independent review.</p><div class="stack">')
  for m in ms:
   out.append(f'<article class="listcard"><h3>{sanitize(m["title"])} <span class="badge">{sanitize(m["id"])}</span></h3><p><strong>Starting condition:</strong> {sanitize(m["overview"])}</p><p><strong>Procedure:</strong> {sanitize(m["action"])}</p><p><strong>Evidence:</strong> {sanitize(m["metric"])}</p><p><strong>Failure or stop rule:</strong> {sanitize(m["risk"])}</p><details><summary>Five readiness checks</summary><div class="detail"><ol>{"".join("<li>"+sanitize(x)+"</li>" for x in m["readiness"])}</ol></div></details></article>')
  out.append('</div><p><strong>Transfer:</strong> Review source quality, disclosure permission, local rights and applicability. One project cannot establish effectiveness elsewhere.</p></div></details>')
 return '\n'.join(out)
base=shell.replace('__GUIDES__',guides())
compact=lambda obj:json.dumps(obj,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
payload=compact(data);regjs='window.FOUNDRY_REGISTRY='+compact(registry)+';'
standalone=base.replace('__DATA__',payload).replace('__JS__',app+'\n</script>\n<script>'+regjs+'</script>\n<script>'+extension)
assert '__' not in standalone.replace('___','') if False else all(t not in standalone for t in ['__DATA__','__JS__','__GUIDES__'])
assert standalone.count('<script>')>=3,standalone.count('<script>')
standalone_dir=DIST/'standalone';standalone_dir.mkdir(parents=True,exist_ok=True)
(standalone_dir/'index.html').write_text(standalone)
css=re.search(r'<style>([\s\S]*?)</style>',base);assert css
web=base.replace(css.group(0),'<link rel="stylesheet" href="./css/main.css">',1)
web=web.replace('<script type="application/json" id="embedded-data">__DATA__</script>', '<script>window.FOUNDRY_WEB_EDITION=true;</script>\n<script src="./data/embedded.js"></script>\n<script src="./data/registry.js"></script>')
web=web.replace('<script>\n__JS__\n</script>','<script src="./js/core.js"></script>\n<script src="./js/ecosystem.js"></script>')
web=web.replace('</head>','<link rel="manifest" href="./manifest.webmanifest"><link rel="icon" href="./assets/icon.svg" type="image/svg+xml"></head>',1)
assert all(t not in web for t in ['__DATA__','__JS__','__GUIDES__'])
wd=DIST/'web'
for folder in ['css','js','data','assets']:(wd/folder).mkdir(parents=True,exist_ok=True)
(wd/'index.html').write_text(web)
(wd/'css/main.css').write_text(css.group(1))
(wd/'js/core.js').write_text(app)
(wd/'js/ecosystem.js').write_text(extension)
(wd/'data/embedded.js').write_text('window.FOUNDRY_DATA='+compact(data)+';\n')
(wd/'data/registry.js').write_text(regjs+'\n')
shutil.copy2(SRC/'registry.json',wd/'data/registry.json')
# Prebuilt local icons checked into src/assets; builds require Python standard library only.
for icon in ['icon.svg','icon-192.png','icon-512.png']:
 shutil.copy2(SRC/'assets'/icon,wd/'assets'/icon)
manifest={'name':'Foster + Navi Empowerment Foundry','short_name':'Empowerment Foundry','id':'./','start_url':'./index.html','scope':'./','display':'standalone','background_color':'#08131d','theme_color':'#08241e','description':'Local-first generative project commons with declarative modules and portable, buildable applications.','icons':[{'src':'./assets/icon-192.png','sizes':'192x192','type':'image/png','purpose':'any maskable'},{'src':'./assets/icon-512.png','sizes':'512x512','type':'image/png','purpose':'any maskable'}]}
(wd/'manifest.webmanifest').write_text(json.dumps(manifest,indent=2)+'\n')
shutil.copy2(ROOT/'docs/HOSTED_README.md',wd/'README.md')
# Revision = content hash; worker never intercepts third-party domains or other app paths.
precache=['./','./index.html','./css/main.css','./js/core.js','./js/ecosystem.js','./data/embedded.js','./data/registry.js','./assets/icon.svg','./assets/icon-192.png','./assets/icon-512.png','./manifest.webmanifest','./README.md']
revision=hashlib.sha256(''.join(hashlib.sha256((wd/p[2:]).read_bytes()).hexdigest() for p in precache if p!='./').encode()).hexdigest()[:14]
sw=f'''/* Foster + Navi · Versioned, same-origin scoped offline cache. No telemetry, push or background sync. */\n'use strict';\nconst PREFIX='foster_navi_foundry_v2_';\nconst CACHE=PREFIX+'{revision}';\nconst ASSETS={json.dumps(precache)};\nself.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting())));\nself.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith(PREFIX)&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));\nself.addEventListener('fetch',event=>{{const req=event.request;if(req.method!=='GET')return;const url=new URL(req.url);if(url.origin!==self.location.origin||!url.pathname.startsWith(new URL(self.registration.scope).pathname))return;event.respondWith(caches.match(req).then(hit=>hit||fetch(req)));}});\n'''
(wd/'sw.js').write_text(sw)
license='''MIT License\n\nCopyright (c) 2026 Foster + Navi\n\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:\n\nThe above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.\n\nTHE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY.\n'''
(ROOT/'LICENSE').write_text(license);(wd/'LICENSE').write_text(license);(standalone_dir/'LICENSE').write_text(license);shutil.copy2(standalone_dir/'index.html',ROOT/'index.html')
# Each distribution includes a file-inventory hash manifest. A local build-clock timestamp is not precedence evidence.
for edition in [standalone_dir,wd]:
 listing={str(p.relative_to(edition)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(edition.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.json'}
 (edition/'SHA256SUMS.json').write_text(json.dumps({'algorithm':'SHA-256','hashes':listing,'limitation':'Byte identity only; no independent creation time, authorship or certification.'},indent=2)+'\n')
release={'format':'empowerment_foundry_release/2','revision':revision,'contents':{'domains':len(data['domains']),'methods':len(data['methods']),'technology_references':len(data['technology']),'declarative_modules':len(registry['modules'])},'editions':{'standalone':'dist/standalone/index.html','hosted':'dist/web/index.html'},'scope':'Reproducible files and structural tests only; no external user, professional, accessibility or impact certification.','files':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ROOT.rglob('*')) if p.is_file() and not p.name in ('release_manifest.json','empowerment_foundry_v2_ecosystem.zip') and '__pycache__' not in str(p) and 'tests/child_temp/' not in str(p.relative_to(ROOT)) and p.name not in ('generated_child_test.zip','invalid_module_pack.json')}}
(ROOT/'release_manifest.json').write_text(json.dumps(release,indent=2)+'\n')
print('Built standalone:',(standalone_dir/'index.html').stat().st_size,'bytes')
print('Built web:',(wd/'index.html').stat().st_size,'bytes; assets:',len([x for x in wd.rglob('*') if x.is_file()]),'; cache revision:',revision)
print('Modules:',len(registry['modules']),'Methods:',len(data['methods']),'Technology:',len(data['technology']))
